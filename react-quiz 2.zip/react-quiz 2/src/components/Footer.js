function Footer({children}) {
    return (
        <return>
            <footer>{children}</footer>
            
        </return>
    )
}

export default Footer
